import React from 'react';
import Sistema from './components/Sistema';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div className="App">
      <Sistema />
    </div>
  );
}

export default App;
