import React, { Component } from 'react';

export default class Atendimento extends Component {

    render() {
        return (
            <div className="d-inline-block" style={{ marginLeft: '5px' }}>
                <h3>
                    <span className="badge badge-primary">
                        {this.props.text}
                    </span>
                </h3>
            </div>
        );
    }
}